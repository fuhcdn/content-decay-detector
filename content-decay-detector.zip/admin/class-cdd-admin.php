<?php
/**
 * 後台管理介面 — 選單、儀表板頁面、手動掃描 AJAX 動作。
 *
 * @package Content_Decay_Detector
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class CDD_Admin {

	/**
	 * 掛勾註冊。
	 */
	public static function init() {
		add_action( 'admin_menu', array( __CLASS__, 'register_menu' ) );
		add_action( 'admin_enqueue_scripts', array( __CLASS__, 'enqueue_assets' ) );
		add_action( 'wp_ajax_cdd_manual_scan', array( __CLASS__, 'handle_manual_scan' ) );
		add_action( 'admin_notices', array( __CLASS__, 'maybe_show_upgrade_notice' ) );
	}

	/**
	 * 新增後台選單項目。
	 */
	public static function register_menu() {
		add_menu_page(
			__( '內容衰退偵測', 'content-decay-detector' ),
			__( '內容衰退偵測', 'content-decay-detector' ),
			'manage_options',
			'content-decay-detector',
			array( __CLASS__, 'render_dashboard' ),
			'dashicons-chart-line',
			80
		);

		add_submenu_page(
			'content-decay-detector',
			__( '設定', 'content-decay-detector' ),
			__( '設定', 'content-decay-detector' ),
			'manage_options',
			'content-decay-detector-settings',
			array( __CLASS__, 'render_settings' )
		);
	}

	/**
	 * 只喺外掛自己嘅頁面載入 CSS/JS，避免影響其他頁面效能。
	 *
	 * @param string $hook
	 */
	public static function enqueue_assets( $hook ) {
		if ( strpos( $hook, 'content-decay-detector' ) === false ) {
			return;
		}

		wp_enqueue_style(
			'cdd-admin-style',
			CDD_PLUGIN_URL . 'assets/css/admin.css',
			array(),
			CDD_VERSION
		);

		wp_enqueue_script(
			'cdd-admin-script',
			CDD_PLUGIN_URL . 'assets/js/admin.js',
			array( 'jquery' ),
			CDD_VERSION,
			true
		);

		wp_localize_script(
			'cdd-admin-script',
			'cddAdmin',
			array(
				'ajaxUrl' => admin_url( 'admin-ajax.php' ),
				'nonce'   => wp_create_nonce( 'cdd_manual_scan_nonce' ),
				'i18n'    => array(
					'scanning' => __( '掃描中，請稍候…', 'content-decay-detector' ),
					'done'     => __( '掃描完成！', 'content-decay-detector' ),
				),
			)
		);
	}

	/**
	 * 渲染主儀表板頁面。
	 */
	public static function render_dashboard() {
		if ( ! current_user_can( 'manage_options' ) ) {
			return;
		}
		$results      = CDD_Cron::get_last_results();
		$last_run     = CDD_Cron::get_last_run_time();
		$is_pro       = cdd_fs_is_pro_active();
		$post_count   = wp_count_posts()->publish;
		$over_limit   = ! $is_pro && $post_count > CDD_FREE_POST_LIMIT;

		include CDD_PLUGIN_DIR . 'admin/views/dashboard.php';
	}

	/**
	 * 渲染設定頁面。
	 */
	public static function render_settings() {
		if ( ! current_user_can( 'manage_options' ) ) {
			return;
		}
		include CDD_PLUGIN_DIR . 'admin/views/settings.php';
	}

	/**
	 * AJAX：手動觸發一次掃描（唔使等排程）。
	 */
	public static function handle_manual_scan() {
		check_ajax_referer( 'cdd_manual_scan_nonce', 'nonce' );

		if ( ! current_user_can( 'manage_options' ) ) {
			wp_send_json_error( array( 'message' => __( '權限不足', 'content-decay-detector' ) ), 403 );
		}

		$results = CDD_Cron::run_scan();

		wp_send_json_success(
			array(
				'message' => __( '掃描完成', 'content-decay-detector' ),
				'count'   => count( $results ),
			)
		);
	}

	/**
	 * 免費版文章數超過上限時，喺後台顯示升級提示（非強制彈窗，純資訊性）。
	 */
	public static function maybe_show_upgrade_notice() {
		$screen = get_current_screen();
		if ( ! $screen || strpos( $screen->id, 'content-decay-detector' ) === false ) {
			return;
		}

		if ( cdd_fs_is_pro_active() ) {
			return;
		}

		$post_count = wp_count_posts()->publish;
		if ( $post_count <= CDD_FREE_POST_LIMIT ) {
			return;
		}
		?>
		<div class="notice notice-info">
			<p>
				<?php
				printf(
					/* translators: %d = 文章總數 */
					esc_html__( '你嘅網站有 %1$d 篇已發佈文章，免費版目前只掃描最舊嘅 %2$d 篇。升級 Pro 版可解鎖無限文章掃描、Google Search Console 流量整合同 AI 改寫建議。', 'content-decay-detector' ),
					(int) $post_count,
					(int) CDD_FREE_POST_LIMIT
				);
				?>
			</p>
		</div>
		<?php
	}
}
