<?php
/**
 * Email 通知器 — 掃描完成後將結果整理成清單寄畀站主。
 *
 * @package Content_Decay_Detector
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class CDD_Notifier {

	/**
	 * 寄出每週掃描摘要 email。
	 *
	 * @param array $results 由 CDD_Cron::run_scan() 產生嘅掃描結果陣列。
	 * @return bool 是否成功送出（實際送出結果由 wp_mail 決定）。
	 */
	public static function send_weekly_summary( $results ) {
		if ( empty( $results ) ) {
			return false;
		}

		// 只通知 decaying / critical 等級嘅文章，避免郵件過長冇重點
		$flagged = array_filter(
			$results,
			function ( $item ) {
				return in_array( $item['grade'], array( 'decaying', 'critical' ), true );
			}
		);

		if ( empty( $flagged ) ) {
			return false; // 全部健康，唔需要打擾站主
		}

		// 依分數由低到高排序（最急需處理排最先）
		usort(
			$flagged,
			function ( $a, $b ) {
				return $a['score'] <=> $b['score'];
			}
		);

		$recipient = self::get_recipient_email();
		$subject   = sprintf(
			/* translators: %d = 過時文章數量 */
			__( '[%1$s] 每週內容健康報告：%2$d 篇文章需要關注', 'content-decay-detector' ),
			wp_specialchars_decode( get_bloginfo( 'name' ), ENT_QUOTES ),
			count( $flagged )
		);

		$body = self::build_email_body( $flagged );

		$headers = array( 'Content-Type: text/html; charset=UTF-8' );

		return wp_mail( $recipient, $subject, $body, $headers );
	}

	/**
	 * 決定通知收件人 email：優先用外掛設定頁指定嘅地址，否則 fallback 去 admin_email。
	 *
	 * @return string
	 */
	public static function get_recipient_email() {
		$custom = get_option( 'cdd_notification_email', '' );
		if ( ! empty( $custom ) && is_email( $custom ) ) {
			return $custom;
		}
		return get_option( 'admin_email' );
	}

	/**
	 * 產生 email HTML 內容。
	 *
	 * @param array $flagged
	 * @return string
	 */
	private static function build_email_body( $flagged ) {
		ob_start();
		?>
		<div style="font-family: Arial, sans-serif; max-width: 640px; margin: 0 auto;">
			<h2 style="color: #1d2327;"><?php esc_html_e( '內容健康報告', 'content-decay-detector' ); ?></h2>
			<p><?php esc_html_e( '以下文章嘅健康分數偏低，建議盡快檢視同更新：', 'content-decay-detector' ); ?></p>
			<table style="width: 100%; border-collapse: collapse;">
				<thead>
					<tr style="background: #f0f0f1; text-align: left;">
						<th style="padding: 8px; border: 1px solid #ddd;"><?php esc_html_e( '文章', 'content-decay-detector' ); ?></th>
						<th style="padding: 8px; border: 1px solid #ddd;"><?php esc_html_e( '分數', 'content-decay-detector' ); ?></th>
						<th style="padding: 8px; border: 1px solid #ddd;"><?php esc_html_e( '主要原因', 'content-decay-detector' ); ?></th>
					</tr>
				</thead>
				<tbody>
					<?php foreach ( $flagged as $item ) : ?>
						<tr>
							<td style="padding: 8px; border: 1px solid #ddd;">
								<a href="<?php echo esc_url( get_edit_post_link( $item['post_id'], 'raw' ) ); ?>">
									<?php echo esc_html( $item['title'] ); ?>
								</a>
							</td>
							<td style="padding: 8px; border: 1px solid #ddd;">
								<?php echo esc_html( $item['score'] ); ?>/100
								(<?php echo esc_html( CDD_Scorer::grade_label( $item['grade'] ) ); ?>)
							</td>
							<td style="padding: 8px; border: 1px solid #ddd;">
								<?php echo esc_html( implode( '；', array_values( $item['factors'] ) ) ); ?>
							</td>
						</tr>
					<?php endforeach; ?>
				</tbody>
			</table>
			<p style="margin-top: 20px;">
				<a href="<?php echo esc_url( admin_url( 'admin.php?page=content-decay-detector' ) ); ?>"
					style="background: #2271b1; color: #fff; padding: 10px 16px; text-decoration: none; border-radius: 4px;">
					<?php esc_html_e( '查看完整儀表板', 'content-decay-detector' ); ?>
				</a>
			</p>
			<p style="color: #777; font-size: 12px; margin-top: 24px;">
				<?php esc_html_e( '此郵件由 Content Decay Detector 外掛自動發送。', 'content-decay-detector' ); ?>
			</p>
		</div>
		<?php
		return ob_get_clean();
	}
}
