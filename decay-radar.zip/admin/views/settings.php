<?php
/**
 * 設定頁面檢視。
 *
 * @package Content_Decay_Detector
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}
?>
<div class="wrap">
	<h1><?php esc_html_e( '內容衰退偵測 — 設定', 'decay-radar' ); ?></h1>

	<form method="post" action="options.php">
		<?php settings_fields( CDD_Settings::OPTION_GROUP ); ?>
		<table class="form-table" role="presentation">
			<tr>
				<th scope="row">
					<label for="cdd_notification_email"><?php esc_html_e( '通知 Email 地址', 'decay-radar' ); ?></label>
				</th>
				<td>
					<input
						type="email"
						id="cdd_notification_email"
						name="cdd_notification_email"
						value="<?php echo esc_attr( get_option( 'cdd_notification_email', get_option( 'admin_email' ) ) ); ?>"
						class="regular-text"
					/>
					<p class="description">
						<?php esc_html_e( '每週掃描報告會寄到呢個地址。留空則預設使用網站管理員 email。', 'decay-radar' ); ?>
					</p>
				</td>
			</tr>
		</table>
		<?php submit_button(); ?>
	</form>
</div>
