<?php
/**
 * 儀表板檢視 — 顯示上次掃描結果清單。
 *
 * 此檔案由 CDD_Admin::render_dashboard() include，
 * 依賴變數：$results, $last_run, $is_pro, $post_count, $over_limit
 *
 * @package Content_Decay_Detector
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}
?>
<div class="wrap cdd-dashboard">
	<h1><?php esc_html_e( '內容衰退偵測 — 儀表板', 'decay-radar' ); ?></h1>

	<p class="cdd-subtitle">
		<?php
		if ( $last_run ) {
			printf(
				/* translators: %s = 上次掃描時間 */
				esc_html__( '上次掃描時間：%s', 'decay-radar' ),
				esc_html( date_i18n( get_option( 'date_format' ) . ' ' . get_option( 'time_format' ), $last_run ) )
			);
		} else {
			esc_html_e( '尚未執行過掃描。點擊下方按鈕開始第一次掃描。', 'decay-radar' );
		}
		?>
	</p>

	<button type="button" id="cdd-manual-scan-btn" class="button button-primary">
		<?php esc_html_e( '立即手動掃描', 'decay-radar' ); ?>
	</button>
	<span id="cdd-scan-status" style="margin-left: 10px;"></span>

	<?php if ( ! empty( $results ) ) : ?>
		<table class="wp-list-table widefat fixed striped" style="margin-top: 20px;">
			<thead>
				<tr>
					<th><?php esc_html_e( '文章標題', 'decay-radar' ); ?></th>
					<th style="width: 120px;"><?php esc_html_e( '健康分數', 'decay-radar' ); ?></th>
					<th style="width: 120px;"><?php esc_html_e( '等級', 'decay-radar' ); ?></th>
					<th><?php esc_html_e( '主要原因', 'decay-radar' ); ?></th>
					<th style="width: 100px;"><?php esc_html_e( '操作', 'decay-radar' ); ?></th>
				</tr>
			</thead>
			<tbody>
				<?php
				// 依分數由低到高排序，最急需處理排最上面
				usort(
					$results,
					function ( $a, $b ) {
						return $a['score'] <=> $b['score'];
					}
				);
				foreach ( $results as $item ) :
					?>
					<tr>
						<td><strong><?php echo esc_html( $item['title'] ); ?></strong></td>
						<td><?php echo esc_html( $item['score'] ); ?>/100</td>
						<td>
							<span class="cdd-badge cdd-badge-<?php echo esc_attr( $item['grade'] ); ?>">
								<?php echo esc_html( CDD_Scorer::grade_label( $item['grade'] ) ); ?>
							</span>
						</td>
						<td>
							<?php
							if ( ! empty( $item['factors'] ) ) {
								echo esc_html( implode( '；', array_values( $item['factors'] ) ) );
							} else {
								esc_html_e( '暫無明顯問題', 'decay-radar' );
							}
							?>
						</td>
						<td>
							<a href="<?php echo esc_url( get_edit_post_link( $item['post_id'] ) ); ?>" class="button button-small">
								<?php esc_html_e( '編輯文章', 'decay-radar' ); ?>
							</a>
						</td>
					</tr>
				<?php endforeach; ?>
			</tbody>
		</table>
	<?php else : ?>
		<p><?php esc_html_e( '暫時未有掃描結果。', 'decay-radar' ); ?></p>
	<?php endif; ?>

	<?php if ( $over_limit ) : ?>
		<div class="notice notice-info inline" style="margin-top: 20px;">
			<p>
				<?php
				printf(
					/* translators: 1: 文章總數 2: 免費版上限 */
					esc_html__( '你有 %1$d 篇文章，免費版只掃描最舊嘅 %2$d 篇。升級 Pro 版可解鎖無限文章掃描。', 'decay-radar' ),
					(int) $post_count,
					(int) CDD_FREE_POST_LIMIT
				);
				?>
			</p>
		</div>
	<?php endif; ?>

	<?php if ( ! $is_pro ) : ?>
		<div class="cdd-upgrade-box" style="margin-top: 24px; padding: 20px; background: #fff; border: 1px solid #c3c4c7; border-left: 4px solid #2271b1;">
			<h3><?php esc_html_e( '升級 Pro 版，解鎖更多功能', 'decay-radar' ); ?></h3>
			<ul style="list-style: disc; padding-left: 20px;">
				<li><?php esc_html_e( '無限文章掃描（免費版限 100 篇）', 'decay-radar' ); ?></li>
			</ul>
			<p style="color: #777; font-size: 12px; margin-bottom: 16px;">
				<?php esc_html_e( '計劃中：Google Search Console 流量整合、AI 更新建議、多站點管理（Agency）。', 'decay-radar' ); ?>
			</p>
			<p>
				<?php
				$cdd_fs_upgrade = cdd_fs();
				$cdd_upgrade_url = ( $cdd_fs_upgrade && method_exists( $cdd_fs_upgrade, 'get_upgrade_url' ) )
					? $cdd_fs_upgrade->get_upgrade_url()
					: 'https://checkout.freemius.com/plugin/39146/plan/65485/';
				?>
				<a href="<?php echo esc_url( $cdd_upgrade_url ); ?>" target="_blank" rel="noopener noreferrer" class="button button-primary">
					<?php esc_html_e( '升級 Pro 版', 'decay-radar' ); ?>
				</a>
			</p>
		</div>
	<?php endif; ?>
</div>
