<?php
/**
 * Plugin Name:       Decay Radar
 * Plugin URI:        https://contentdecaydetector.com
 * Description:       自動偵測你網站入面正在流失SEO排名嘅過時文章 — 每週掃描，計算內容健康分數，用email通知你邊啲文章需要更新。免費版最多掃描100篇，Pro版解鎖無限掃描。
 * Version:           1.0.0
 * Requires at least: 5.8
 * Requires PHP:      7.4
 * Author:            Yanlee
 * Author URI:        https://profiles.wordpress.org/yanlee/
 * License:           GPL v2 or later
 * License URI:       https://www.gnu.org/licenses/gpl-2.0.html
 * Text Domain:       decay-radar
 * Domain Path:       /languages
 * @fs_premium_only    /includes/pro/
 */

// 防止直接存取
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

// ------------------------------------------------------------------
// 常數定義
// ------------------------------------------------------------------
define( 'CDD_VERSION', '1.0.0' );
define( 'CDD_PLUGIN_FILE', __FILE__ );
define( 'CDD_PLUGIN_DIR', plugin_dir_path( __FILE__ ) );
define( 'CDD_PLUGIN_URL', plugin_dir_url( __FILE__ ) );
define( 'CDD_FREE_POST_LIMIT', 100 ); // 免費版文章數量上限
define( 'CDD_CRON_HOOK', 'cdd_weekly_scan_event' );

// ------------------------------------------------------------------
// Freemius SDK 整合（付費授權管理）
//
// 下面 3 個常數係唯一需要喺取得 Freemius Dashboard > SDK Integration
// 頁面嘅真實憑證後填入嘅位置。喺填入之前，PRODUCT_ID 保持為 0，
// 外掛會自動偵測並跳過 Freemius 初始化（安全降級為純免費版行為），
// 唔會因為缺少憑證而報錯或白畫面。
// ------------------------------------------------------------------
if ( ! defined( 'CDD_FS_PRODUCT_ID' ) ) {
	define( 'CDD_FS_PRODUCT_ID', 39146 ); // Freemius Dashboard 嘅 Product ID
}
if ( ! defined( 'CDD_FS_PUBLIC_KEY' ) ) {
	define( 'CDD_FS_PUBLIC_KEY', 'pk_711b9a9988dea6bc1aa20a50c392c' ); // Freemius Public Key（公開金鑰，可安全內嵌於代碼）
}
if ( ! defined( 'CDD_FS_SLUG' ) ) {
	define( 'CDD_FS_SLUG', 'content-decay-detector' ); // Freemius 產品頁設定嘅 slug
}

if ( ! function_exists( 'cdd_fs' ) ) {
	/**
	 * Freemius SDK 存取入口（官方建議命名模式：<prefix>_fs()）。
	 *
	 * 只有喺 CDD_FS_PRODUCT_ID 已填入真實數值時先會初始化 SDK，
	 * 避免憑證未到位時外掛出錯。
	 *
	 * @return Freemius|null
	 */
	function cdd_fs() {
		global $cdd_fs;

		if ( ! isset( $cdd_fs ) ) {
			// 憑證未填入時完全唔載入 SDK，維持純免費版行為。
			if ( empty( CDD_FS_PRODUCT_ID ) || empty( CDD_FS_PUBLIC_KEY ) ) {
				return null;
			}

			require_once CDD_PLUGIN_DIR . 'freemius/start.php';

			$cdd_fs = fs_dynamic_init(
				array(
					'id'                  => CDD_FS_PRODUCT_ID,
					'slug'                => CDD_FS_SLUG,
					'premium_slug'        => CDD_FS_SLUG . '-premium',
					'type'                => 'plugin',
					'public_key'          => CDD_FS_PUBLIC_KEY,
					'is_premium'          => false, // 主代碼庫本身作為免費版基底發佈到 WordPress.org
					'has_premium_version' => true,
					'has_addons'          => false,
					'has_paid_plans'      => true,
					'is_org_compliant'    => true, // 免費版完整可用，唔含任何人為限制
					'menu'                => array(
						'slug'    => 'decay-radar',
						'account' => true,
						'support' => true,
						'contact' => false,
						'pricing' => true,
					),
				)
			);
		}

		return $cdd_fs;
	}

	// 依 Freemius SDK 慣例，儘早初始化（唔可以放喺 plugins_loaded 之後）。
	cdd_fs();

	if ( cdd_fs() ) {
		do_action( 'cdd_fs_loaded' );
	}
}

/**
 * 統一嘅 Pro 版狀態檢查入口，供全外掛代碼調用。
 * SDK 未接入時安全降級為 false（免費版行為）。
 *
 * @return bool
 */
function cdd_fs_is_pro_active() {
	$fs = cdd_fs();
	if ( $fs && method_exists( $fs, 'can_use_premium_code' ) ) {
		return $fs->can_use_premium_code();
	}
	return false;
}

// ------------------------------------------------------------------
// 核心檔案載入
// ------------------------------------------------------------------
require_once CDD_PLUGIN_DIR . 'includes/class-cdd-scanner.php';
require_once CDD_PLUGIN_DIR . 'includes/class-cdd-scorer.php';
require_once CDD_PLUGIN_DIR . 'includes/class-cdd-notifier.php';
require_once CDD_PLUGIN_DIR . 'includes/class-cdd-cron.php';
require_once CDD_PLUGIN_DIR . 'includes/class-cdd-settings.php';

if ( is_admin() ) {
	require_once CDD_PLUGIN_DIR . 'admin/class-cdd-admin.php';
}

// ------------------------------------------------------------------
// 啟用 / 停用 / 解除安裝 掛勾
// ------------------------------------------------------------------
register_activation_hook( __FILE__, array( 'CDD_Cron', 'activate' ) );
register_deactivation_hook( __FILE__, array( 'CDD_Cron', 'deactivate' ) );

/**
 * 外掛初始化。
 */
function cdd_init_plugin() {
	load_plugin_textdomain( 'decay-radar', false, dirname( plugin_basename( __FILE__ ) ) . '/languages' );

	CDD_Cron::init();
	CDD_Settings::init();

	if ( is_admin() ) {
		CDD_Admin::init();
	}
}
add_action( 'plugins_loaded', 'cdd_init_plugin' );
