/**
 * 後台儀表板互動邏輯 — 手動觸發掃描。
 */
( function ( $ ) {
	'use strict';

	$( document ).ready( function () {
		var $btn    = $( '#cdd-manual-scan-btn' );
		var $status = $( '#cdd-scan-status' );

		if ( ! $btn.length ) {
			return;
		}

		$btn.on( 'click', function () {
			$btn.prop( 'disabled', true );
			$status.text( cddAdmin.i18n.scanning );

			$.post( cddAdmin.ajaxUrl, {
				action: 'cdd_manual_scan',
				nonce: cddAdmin.nonce
			} )
				.done( function ( response ) {
					if ( response.success ) {
						$status.text( cddAdmin.i18n.done );
						// 重新整理頁面以顯示最新掃描結果
						setTimeout( function () {
							window.location.reload();
						}, 800 );
					} else {
						$status.text( response.data && response.data.message ? response.data.message : 'Error' );
						$btn.prop( 'disabled', false );
					}
				} )
				.fail( function () {
					$status.text( 'Request failed.' );
					$btn.prop( 'disabled', false );
				} );
		} );
	} );
} )( jQuery );
