<?php
/**
 * 內容健康分數計算器。
 *
 * 分數範圍 0-100，分數愈低代表文章愈需要更新。
 * 免費版計分因子：文章年齡、失效外部連結比例、有否更新過。
 * Pro 版額外因子（GSC 流量趨勢）留有 filter hook，留待 Pro 模組接入。
 *
 * @package Content_Decay_Detector
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class CDD_Scorer {

	/**
	 * 計算單篇文章嘅健康分數。
	 *
	 * @param WP_Post $post
	 * @param array   $link_check_result array( 'total' => int, 'broken' => int )
	 * @return array {
	 *     @type int    $score      0-100
	 *     @type string $grade      'healthy' | 'aging' | 'decaying' | 'critical'
	 *     @type array  $factors    計分明細，方便 email/後台顯示
	 * }
	 */
	public static function calculate( $post, $link_check_result = array( 'total' => 0, 'broken' => 0 ) ) {
		$score   = 100;
		$factors = array();

		// 因子一：文章年齡（發佈日期距今幾耐）
		$published_ts = strtotime( $post->post_date );
		$modified_ts  = strtotime( $post->post_modified );
		$now_ts       = current_time( 'timestamp' );

		$age_days = max( 0, floor( ( $now_ts - $published_ts ) / DAY_IN_SECONDS ) );

		if ( $age_days > 730 ) {
			$score              -= 30;
			$factors['age']      = sprintf( '文章已發佈超過 2 年（%d 日），內容可能已過時', $age_days );
		} elseif ( $age_days > 365 ) {
			$score              -= 15;
			$factors['age']      = sprintf( '文章已發佈超過 1 年（%d 日）', $age_days );
		}

		// 因子二：距離上次更新嘅時間（判斷是否「發佈後從未更新」）
		$days_since_update = max( 0, floor( ( $now_ts - $modified_ts ) / DAY_IN_SECONDS ) );
		if ( $days_since_update > 365 ) {
			$score                        -= 20;
			$factors['stale_update']       = sprintf( '超過 1 年未更新（上次更新：%d 日前）', $days_since_update );
		}

		// 因子三：失效外部連結比例
		if ( $link_check_result['total'] > 0 ) {
			$broken_ratio = $link_check_result['broken'] / $link_check_result['total'];
			if ( $broken_ratio > 0 ) {
				$penalty                        = min( 30, round( $broken_ratio * 30 ) );
				$score                          -= $penalty;
				$factors['broken_links']         = sprintf(
					'%d/%d 個外部連結已失效（扣 %d 分）',
					$link_check_result['broken'],
					$link_check_result['total'],
					$penalty
				);
			}
		}

		/**
		 * 讓 Pro 版模組（GSC 流量趨勢、AI 內容評估）擴充計分邏輯。
		 *
		 * @param int     $score  目前分數
		 * @param WP_Post $post   文章物件
		 * @param array   $factors 計分明細（by reference 唔支援，用 filter 回傳陣列處理）
		 */
		$pro_result = apply_filters( 'cdd_pro_score_adjustment', array( 'delta' => 0, 'factors' => array() ), $post );
		if ( ! empty( $pro_result['delta'] ) ) {
			$score  += $pro_result['delta'];
			$factors = array_merge( $factors, $pro_result['factors'] );
		}

		$score = max( 0, min( 100, $score ) );

		return array(
			'score'   => (int) $score,
			'grade'   => self::score_to_grade( $score ),
			'factors' => $factors,
		);
	}

	/**
	 * 將分數轉成人類可讀嘅等級標籤。
	 *
	 * @param int $score
	 * @return string
	 */
	public static function score_to_grade( $score ) {
		if ( $score >= 80 ) {
			return 'healthy';
		} elseif ( $score >= 60 ) {
			return 'aging';
		} elseif ( $score >= 40 ) {
			return 'decaying';
		}
		return 'critical';
	}

	/**
	 * 等級標籤轉做中文顯示文字。
	 *
	 * @param string $grade
	 * @return string
	 */
	public static function grade_label( $grade ) {
		$labels = array(
			'healthy'  => __( '健康', 'decay-radar' ),
			'aging'    => __( '開始老化', 'decay-radar' ),
			'decaying' => __( '正在衰退', 'decay-radar' ),
			'critical' => __( '急需更新', 'decay-radar' ),
		);
		return isset( $labels[ $grade ] ) ? $labels[ $grade ] : $grade;
	}
}
