<?php
/**
 * 排程管理器 — 負責每週自動掃描嘅 WP Cron 排程同執行邏輯。
 *
 * @package Content_Decay_Detector
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class CDD_Cron {

	const RESULTS_OPTION = 'cdd_last_scan_results';
	const LAST_RUN_OPTION = 'cdd_last_scan_timestamp';

	/**
	 * 註冊 cron hook 同自訂排程週期。
	 */
	public static function init() {
		add_filter( 'cron_schedules', array( __CLASS__, 'register_weekly_schedule' ) );
		add_action( CDD_CRON_HOOK, array( __CLASS__, 'run_scan' ) );
	}

	/**
	 * 外掛啟用時：排定每週掃描任務（若尚未排定）。
	 */
	public static function activate() {
		if ( ! wp_next_scheduled( CDD_CRON_HOOK ) ) {
			wp_schedule_event( time() + HOUR_IN_SECONDS, 'weekly', CDD_CRON_HOOK );
		}
	}

	/**
	 * 外掛停用時：清除排程，避免殘留任務。
	 */
	public static function deactivate() {
		$timestamp = wp_next_scheduled( CDD_CRON_HOOK );
		if ( $timestamp ) {
			wp_unschedule_event( $timestamp, CDD_CRON_HOOK );
		}
	}

	/**
	 * 確保 WordPress 有 'weekly' 這個排程週期（核心預設冇提供）。
	 *
	 * @param array $schedules
	 * @return array
	 */
	public static function register_weekly_schedule( $schedules ) {
		if ( ! isset( $schedules['weekly'] ) ) {
			$schedules['weekly'] = array(
				'interval' => WEEK_IN_SECONDS,
				'display'  => __( '每週一次', 'decay-radar' ),
			);
		}
		return $schedules;
	}

	/**
	 * 執行完整掃描流程：抓文章 → 檢查連結 → 計分 → 儲存結果 → 寄email。
	 *
	 * 設有 30 秒每篇文章嘅連結檢查上限保護，避免大型網站掃描逾時；
	 * 連結檢查數量本身亦受 `cdd_max_links_per_post` filter 限制。
	 */
	public static function run_scan() {
		$posts   = CDD_Scanner::get_scannable_posts();
		$results = array();

		foreach ( $posts as $post ) {
			$links       = CDD_Scanner::extract_external_links( $post );
			$max_links   = apply_filters( 'cdd_max_links_per_post', 10 );
			$links       = array_slice( $links, 0, $max_links );

			$broken = 0;
			foreach ( $links as $link ) {
				if ( ! CDD_Scanner::is_link_alive( $link ) ) {
					++$broken;
				}
			}

			$link_check = array(
				'total'  => count( $links ),
				'broken' => $broken,
			);

			$score_data = CDD_Scorer::calculate( $post, $link_check );

			$results[] = array(
				'post_id' => $post->ID,
				'title'   => get_the_title( $post ),
				'score'   => $score_data['score'],
				'grade'   => $score_data['grade'],
				'factors' => $score_data['factors'],
			);
		}

		update_option( self::RESULTS_OPTION, $results, false );
		update_option( self::LAST_RUN_OPTION, current_time( 'timestamp' ), false );

		CDD_Notifier::send_weekly_summary( $results );

		/**
		 * 掃描完成後觸發，方便 Pro 版或第三方擴充（例如 Slack 通知）掛勾。
		 *
		 * @param array $results
		 */
		do_action( 'cdd_scan_completed', $results );

		return $results;
	}

	/**
	 * 取得上次掃描結果（供後台儀表板顯示）。
	 *
	 * @return array
	 */
	public static function get_last_results() {
		return get_option( self::RESULTS_OPTION, array() );
	}

	/**
	 * 取得上次掃描時間戳記。
	 *
	 * @return int|false
	 */
	public static function get_last_run_time() {
		return get_option( self::LAST_RUN_OPTION, false );
	}
}
