<?php
/**
 * 設定管理 — 註冊外掛設定並提供讀寫介面。
 *
 * @package Content_Decay_Detector
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class CDD_Settings {

	const OPTION_GROUP = 'cdd_settings_group';

	/**
	 * 註冊設定欄位（WordPress Settings API）。
	 */
	public static function init() {
		add_action( 'admin_init', array( __CLASS__, 'register_settings' ) );
	}

	/**
	 * 註冊可設定嘅選項：通知 email 地址。
	 */
	public static function register_settings() {
		register_setting(
			self::OPTION_GROUP,
			'cdd_notification_email',
			array(
				'type'              => 'string',
				'sanitize_callback' => 'sanitize_email',
				'default'           => get_option( 'admin_email' ),
			)
		);
	}
}
