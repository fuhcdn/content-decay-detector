<?php
/**
 * 內容掃描器 — 負責從資料庫抓取需要評估嘅文章清單。
 *
 * @package Content_Decay_Detector
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class CDD_Scanner {

	/**
	 * 抓取所有已發佈嘅文章（post + page，可用 filter 擴充），
	 * 免費版限制最多 CDD_FREE_POST_LIMIT 篇（依發佈日期由舊到新排序，
	 * 確保優先掃描最可能衰退嘅舊文章）。
	 *
	 * @return WP_Post[]
	 */
	public static function get_scannable_posts() {
		$is_pro = cdd_fs_is_pro_active();

		$args = array(
			'post_type'      => apply_filters( 'cdd_scannable_post_types', array( 'post' ) ),
			'post_status'    => 'publish',
			'orderby'        => 'date',
			'order'          => 'ASC',
			'posts_per_page' => $is_pro ? -1 : CDD_FREE_POST_LIMIT,
			'no_found_rows'  => true,
		);

		$query = new WP_Query( $args );

		return $query->posts;
	}

	/**
	 * 抓取單篇文章入面所有外部連結（http/https，非本站網域）。
	 *
	 * @param WP_Post $post
	 * @return string[] 網址清單
	 */
	public static function extract_external_links( $post ) {
		$content = $post->post_content;
		$links   = array();

		if ( empty( $content ) ) {
			return $links;
		}

		$site_host = wp_parse_url( home_url(), PHP_URL_HOST );

		// 用 DOMDocument 解析 HTML，比 regex 更可靠
		$dom = new DOMDocument();
		// 抑制 HTML5 標籤警告
		libxml_use_internal_errors( true );
		$dom->loadHTML( '<?xml encoding="utf-8" ?>' . $content );
		libxml_clear_errors();

		$anchors = $dom->getElementsByTagName( 'a' );
		foreach ( $anchors as $anchor ) {
			$href = $anchor->getAttribute( 'href' );
			if ( empty( $href ) || strpos( $href, 'http' ) !== 0 ) {
				continue;
			}
			$link_host = wp_parse_url( $href, PHP_URL_HOST );
			if ( $link_host && $link_host !== $site_host ) {
				$links[] = $href;
			}
		}

		return array_unique( $links );
	}

	/**
	 * 檢查單一網址是否仍然存活（HTTP 狀態碼 < 400）。
	 * 使用 HEAD request 減少頻寬消耗；逾時或失敗一律視為「失效」。
	 *
	 * @param string $url
	 * @return bool true = 存活, false = 失效
	 */
	public static function is_link_alive( $url ) {
		$response = wp_remote_head(
			$url,
			array(
				'timeout'     => 8,
				'redirection' => 3,
				'sslverify'   => false,
			)
		);

		if ( is_wp_error( $response ) ) {
			return false;
		}

		$code = wp_remote_retrieve_response_code( $response );

		// 部份伺服器唔支援 HEAD，回傳 405/501 時改用 GET 覆核一次
		if ( in_array( $code, array( 405, 501, 403 ), true ) ) {
			$response = wp_remote_get(
				$url,
				array(
					'timeout'     => 8,
					'redirection' => 3,
					'sslverify'   => false,
				)
			);
			if ( is_wp_error( $response ) ) {
				return false;
			}
			$code = wp_remote_retrieve_response_code( $response );
		}

		return $code > 0 && $code < 400;
	}
}
